d={'name':'a','family':'e', 'class':8}
#g=d.pop('name')
#print(g)
#print(d)
g=d.popitem()
print(g)
print(d)