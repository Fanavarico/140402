l=['a','b','a','c','b','b']
#d={'a':2,'b':3,'c':1}
d={}
for item in l:
    if item in d:
        d[item]=d[item]+1
    else:
        d[item]=1
print(d)

d={'a':1,'b':1}