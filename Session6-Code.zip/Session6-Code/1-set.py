a={1,4,5,5}
b={5,7,8}
#c=set()
#print(type(c))
#print(a)
#print(len(a))
a.add('hello')
print(a)

