d={'a':3,'b':10,'c':8}
c=0
'''
for i in d.values():
    c=c+i
    
for i in d:
    c=c+d[i]'''

f=sum(d.values())

print(f)