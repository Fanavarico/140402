s='python is programming language'
l=s.split(' ')
#print(l)
d={}
for i in l:
    if i in d.keys():
        d[i]=d[i]+1
    else:
        d[i]=1
        
        
print(d)