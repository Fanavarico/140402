t1=[(3,'a','h'),(8,6,'l')]
for i , j, k in t1:
    print(i,':',j,'-->',k)