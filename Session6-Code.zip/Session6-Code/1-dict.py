d={'name':'a','family':'e', 'class':8}
#print(len(d))
#print(d)
#d['name']='r'
#print(d['name'])
#d['age']=20
#i=d.get('name1','not found')
#print(i)
#r=d.values()
#print(type(r))
#print(list(r))
#k=d.keys()
#print(type(k))
i=d.items()
#print(i)
print(type(i))



