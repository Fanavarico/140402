g=(3,'a','h')
a,b,c=g
print('a:',a)
print('b:',b)
print('c:',c)