d1={'a':3,'b':10,'c':8}
d2={'x':30,'y':5}
d={}
'''d=d1.copy()
d['hello']='s'
print(d1)
print(d)'''
d.update(d1)
#d['hello']='s'
d1['hello']='s'
print('d:',d)
print('d1: ',d1)

