d={'name':'a','family':'e', 'class':8}
#d['age']=20
d['class']=d['class']+1
print(d)

