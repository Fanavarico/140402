s={'apple','orange','grape','apple','mango','Apple'}
#print(len(s))
#print(s)
s1={'grape','apple','mango','orange','Apple','orange'}
print(s==s1)