d={'name':'a','family':'e', 'class':8}
#y=d.items()
#print(y)
for i, j in d.items():
    print(i,':',j)