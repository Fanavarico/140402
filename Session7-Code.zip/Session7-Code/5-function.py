def hello(name):
    
    return 'hello '+name

d=hello('reza')
print(d)

