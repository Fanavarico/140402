def hello(name):
    print('hello '+name)
    


i=input('enter name : ')    
hello(i)