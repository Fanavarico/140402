'''def f():
    x=3
    print(x)
    
f()
print(x)
#print(x)
x=3
def f():
   
    print(x)
    
f()
print(x)'''

'''
x=1
def f():
    global x
    x=4
    print('x in function',x)
    
f()
print(x)'''
'''
x=1
def f():

    x=4
    print('x in function',x)
    
f()
print(x)'''

x=10
def f():
    global x
    print('1: ',x)
    x=70
    print('2: ',x)
    
    
f()
print('not function : ',x)