def mas(r):
    p=3.14
    ma=p*r*r
    print(f'masahat : {ma}')
    
def moh(r):
    p=3.14
    mo=p*r*2
    return f'mohit : {mo}'

def main():
    msg=input ('enter your value : محیط یا مساحت :')
    i=float(input('erter your reduis : '))
    if msg=='محیط':
        t=moh(i)
        print(t)
    elif msg=='مساحت':
        mas(i)
        
        
main()