def f(t):
    t['a']+=1
    t['b']-=1
    
d={'a':12,'b':4}
r=f(d)
print(r)
print(f"d['a']: {d['a']}")
print(f"d['b']: {d['b']}")