def hello(name):
    return f'hello {name}'



i=input('enter name: ')
h=hello(i)
print(h)

