def hello():
    return 'hello a'


g=hello()
print(type(g))