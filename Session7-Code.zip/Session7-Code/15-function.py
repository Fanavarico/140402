def f(a):
    a[0]+=1
    a[1]-=1
    
lst=(3,6)
r=f(lst)
print(r)
print(f'lst[0]: {lst[0]}')
print(f'lst[1]: {lst[1]}')