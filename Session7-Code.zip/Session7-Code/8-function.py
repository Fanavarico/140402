def m(i,j):
    if i>j:
        print(f'max value is : {i}')
    elif i==j:
        print(f'{i} equal {j}')
    else:
        print(f'max value is : {j}')



a=int(input('first :'))
b=int(input('second :'))
m(a,b)
