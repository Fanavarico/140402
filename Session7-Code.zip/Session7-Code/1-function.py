def hello():
    print('hello ava')
    

hello()
