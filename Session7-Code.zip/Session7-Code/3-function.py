def jam(num1,num2):
    print(f'sum of {num1} and\
          {num2} is :{num1+num2}')
    



a=int(input('enter first number:'))
b=int(input('enter second number :'))
jam(a,b)