def f(a,b):
    a-=1
    b+=1
    return a,b


x=9
y=4
m,n=f(x,y)
print('x:',m)
print(f'y : {n}')