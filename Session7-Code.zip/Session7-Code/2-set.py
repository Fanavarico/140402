a={2,4,7,6}
b={4,1,5}
#print(a-b)
#h=a.difference(b)
#print(h)
#print(b-a)
#g=b.difference(a)
#print(g)

#i=a.intersection(b)
#print(i)
#print(a&b)
#j=b.intersection(a)
#print(j)

#r=a.union(b)
#print(r)
print(a|b)
