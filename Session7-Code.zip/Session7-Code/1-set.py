s={'apple','orange','Apple','apple','grape','mango'}
#print(len(s))
#print(s)
'''for i in s:
    print(i)'''
    
#s1={'Apple','mango','apple','grape','mango','orange'}
#print(s==s1)
'''
s.add((12,5))
print(s)'''

'''
s.update([12,4])
print(s)'''
'''
s.remove('apple')
print(s)'''
'''
for i in range(2):
    i=input('enter value:')
    s.remove(i)
    
print(s)'''
'''
s.discard('apple1')
print(s)'''

'''
f=s.pop()

print(s)   
print(f) '''
'''
d=s.copy()
print(d)'''
s.clear()
print(s)