import datetime as d
print(d.datetime.now())