import math as m
print(m.fabs(-9))

