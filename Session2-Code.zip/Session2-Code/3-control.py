i=int(input('enter number : '))

if i==0:
    print('Zero')
    
elif i%2==0:
    print('زوج')
    
else:
    print('فرد')
    
