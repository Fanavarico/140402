import math
num=float(input('enter number:'))
if num>0:
    print(math.sqrt(num))
    
else:
    print('not have sqrt')
