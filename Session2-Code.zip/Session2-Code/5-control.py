l=['ava','taha','ali','eli']
s=input('enter name: ')
if s in l:
    print('found')
else:
    print('not found')
