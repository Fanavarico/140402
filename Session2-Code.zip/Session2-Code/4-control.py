l=['ava','taha','ali','eli']
if 'Taha' in l:
    print('found')
else:
    print('not found')