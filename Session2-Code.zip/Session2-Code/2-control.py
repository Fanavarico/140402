import math
num=float(input('enter number:'))
if num>=0:
    print('your number was POS',math.sqrt(num))

elif num<0:
    num=math.fabs(num)
    print('you number was NEG',math.sqrt(num))

