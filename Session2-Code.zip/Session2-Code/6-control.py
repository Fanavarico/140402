w_d=['شنبه','یکشنبه','دوشنبه','سه شنبه','چهارشنبه']
h_d=['پنجشنبه','جمعه']
day=input('enter your day :')
if day in w_d:
    print('go to work')
    
elif day in h_d:
    money=int(input('enter your money: '))
    if money>2000:
        print('go shopping')
    elif money<=2000:
        print('TV')