import random
print(random.choice('eqws'))