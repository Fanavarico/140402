s='hello'
print(len(s))
print(s[4])
