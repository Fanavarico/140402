from datetime import datetime as d
print(d.now())

