d1={'a':9}
def divide(a,b):
    try:
        print(d1['b'])
        d=a/b
        
        print(d)
    except KeyError as e:
        print(e)
        
    
    
    
    
divide(10, 0)
print('hello')
