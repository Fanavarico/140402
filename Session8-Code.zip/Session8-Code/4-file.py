ad='C:/Users/EZ-Tech/Desktop/first/1.txt'
with open(ad) as f:
    s=f.readline()
    print(type(s))
    #print(f.readline(400))
        
        
'''
with open(ad) as f:
    for i in range(3):
        print(f.readline())'''
    