def f(s:str,h=9,*r,**t)->None:
    print(s,t,h,r)
    
    
f(8,77,'o',name='r')
    
    