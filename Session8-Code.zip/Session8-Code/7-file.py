ad='C:/Users/EZ-Tech/Desktop/first/1.txt'
with open(ad,'a') as f:
    l1='hello java\n'
    l2='hello c#\n'
    l3='hello python\n'
    f.write(l1)
    f.write(l3)
    f.write(l2)

