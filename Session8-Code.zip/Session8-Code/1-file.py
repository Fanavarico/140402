f=open('C:/Users/EZ-Tech/Desktop/first/1.txt','w')
l1='hello python\n'
l2='hello c++'
f.write(l1)
f.write(l2)
f.close()