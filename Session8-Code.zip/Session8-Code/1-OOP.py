class Test:
    def set_var(self,a,b):
        self.a=a
        self.b=b
        
    def jam(self):
        return self.a+self.b
    
    def zarb(self):
        return self.a*self.b
    
t1=Test()
t1.set_var(4, 7)
j=t1.jam()
print(f'jam:{j}')
z=t1.zarb()
print(f'zarb : {z}')

