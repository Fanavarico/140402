
try:
    print(a)
except NameError:
    print('error ')
print('hello')
