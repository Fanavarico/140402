ad='C:/Users/EZ-Tech/Desktop/first/1.txt'
with open(ad) as f:
    a=f.read()
    print(type(a))
    #print(f.read(12))