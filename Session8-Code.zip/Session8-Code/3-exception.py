def divide(a,b):
    try:
        d=a/b
        print(d)
    except ZeroDivisionError as ze:
        print(ze)
        
    
    
    
    
divide(10, 5)
print('hello')