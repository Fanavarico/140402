
try:
    print(a)
except NameError as ne:
    print(ne)
print('hello')
