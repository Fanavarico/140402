d1={'a':9}
def divide(a,b):
    try:
        d=a/b
        print(d1['b'])
        
        
        print(d)
    except Exception as e:
        print(e)
    
    
divide(10, 5)
print('hello')

