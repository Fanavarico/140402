def f(**t):
    print(t)
    
    
f(name='ali',family='r')

f(a=1,b=10,c=15,name='reza')