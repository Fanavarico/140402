def f(*t):
    print(t)
    
f(3)
f(5,'ali',8)
f(3.7,6,8,9,0)