ad='C:/Users/EZ-Tech/Desktop/first/1.txt'
with open(ad) as f:
    for item in f:
        print(item)
        

