ad='C:/Users/EZ-Tech/Desktop/first/1.txt'
with open(ad) as f:
    d=f.readlines()
    print(type(d))
    #print(f.readlines())
        