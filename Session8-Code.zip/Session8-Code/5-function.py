def f(*t):
    s=0
    for i in t:
        s=s+i
    print(s)
    
f(4,5)
f(3,9,9.7,6)
f(4)
f(5,6,2,6,8,12,5,50,7)
    
