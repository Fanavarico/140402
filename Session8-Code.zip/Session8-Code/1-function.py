def f(a,b):
    print(a,b)
    

f(3,5)

f(a=3,b=5)

#f(c=5,d=3)
f(5,a=3)