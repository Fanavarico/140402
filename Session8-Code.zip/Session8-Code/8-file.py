ad1='C:/Users/EZ-Tech/Desktop/first/1.txt'
ad2='C:/Users/EZ-Tech/Desktop/first/2.txt'
with open(ad1,'r') as f1 ,open (ad2,'w') as f2:
    for item in f1:
        f2.write(item)