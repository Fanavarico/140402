'''x=9
print(type(x))
print(x)'''
'''
سلام اين بخش براي محاسبه مساحت دايره مي باشد
'''
p=3.14
r=float(input('enter reduis : '))
a=p*(r**2)
print(a)
