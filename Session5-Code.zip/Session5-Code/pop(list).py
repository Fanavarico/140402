l=[12,'5','p',True,14,5.8,12,[3,'a']]
g=l.pop(3)
print(g)
print(l)