e=input('enter event:')
y=input('enter year: ')
ty=input('enter this year :')
print('this isb in this year {1} this {0}\
      event happend\
          '.format(ty,y,e))
