l=[7,50,30,2,6]
'''s=0
for i in l:
    s=s+i
    
print(s)'''
print(sum(l))

