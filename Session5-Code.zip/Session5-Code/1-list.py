l=[12,'5','p',True,14,5.8,12,[3,'a']]
print(type(l))
print(len(l))
