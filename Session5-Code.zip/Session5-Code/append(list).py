l=[12,'5','p',True,14,5.8,12,[3,'a']]
l.append(['204','p',9])
print(l)
