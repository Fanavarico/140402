l=['python', 'is', 'programming', 'language']
h='*'.join(l)
print(h)