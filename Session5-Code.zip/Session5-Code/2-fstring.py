e=input('enter event: ')
y=input('enter year : ')
print(f'in this year {y} it {e} happend')