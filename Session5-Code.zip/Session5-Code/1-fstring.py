e='exhbition'
y=2020
'''
این برنامه پایتون می باشد'''
print(f'in this year {y} this {e} event happend')

