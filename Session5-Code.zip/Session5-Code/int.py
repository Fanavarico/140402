x=2
y=x
y=y+1
print('x:',x)
print('y:',y)