l=[12,'5','p',True,14,5.8,12,[3,'a']]
l.insert(7,'a')
print(l)