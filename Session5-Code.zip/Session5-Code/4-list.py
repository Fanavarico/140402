x=[]
y=x
y.append(5)
print('x:',x)
print('y:',y)
