l=[1,2]
l1=[2,1]
print(l1==l)