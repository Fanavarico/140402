l=[12,'5','p',True,14,5.8,12,[3,'a']]
c=l.count('z')
print(c)