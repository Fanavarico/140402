s='python is programming language'
d=s.split(' ')
print(d)
