s='python'
s[2]='y'
print(s)