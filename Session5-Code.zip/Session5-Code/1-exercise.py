l=[7,50,30,2,6]
'''m=-1
for i in l:
    if i>m:
        m=i
print(m)'''
print(max(l))
print(min(l))