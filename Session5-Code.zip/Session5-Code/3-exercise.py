l=[]
for i in range(1,6):
    a=input('enter value :')
    l.append(a)
    
    
print(l)