l=[12,3,5,'t',True]
for z in l:
    print(z,end='@')
