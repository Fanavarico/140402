a=10
b=a+1
print('a',a)
print('b',b)
