for _ in range(1,11):
    i='hello'
    print(i)


