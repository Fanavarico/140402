a=10

a,b=20,a+1
print('a',a)
print('b',b)