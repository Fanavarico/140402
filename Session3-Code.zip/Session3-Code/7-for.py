s=input('enter string : ')
c=0
for i in s:
    if i in'a':
        c=c+1
        
        
if 'a' not in s:
    print('not fount')

print(c)
