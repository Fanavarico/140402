for i in range(7000000000):
    if i==4:
        break
    
    
    print(i)