s='abcdef'
i=0
while True:
    
    if s[i]=='d':
        continue
        
    i+=1
    print(s[i])
