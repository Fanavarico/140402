i=1
while True:
    i=i+1
    print(i)
    if i==1000000:
        break