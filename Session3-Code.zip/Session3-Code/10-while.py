s='abcdef'
i=0
while True:
    if s[i]=='d':
        print(s[i])
        break
    print(s[i])
    i+=1