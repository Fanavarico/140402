s='abcdef'
i=0
while True:
    i+=1
    if s[i]=='d':
        break
        
    print(s[i])
