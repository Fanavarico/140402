s=input('enter string : ')
c=0
for i in s:
    c+=1
    print(c,'-',i)
    
    
print('the number of chars is : ',c)
