s='abcdef'
i=0
while True:
    if s[i]=='d':
        
        break
        
    print(s[i])
    i+=1