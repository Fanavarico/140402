class Test:
    '''این یک کلاس تست است'''
    def __init__(self,a,b):
        self.a=a
        self.b=b
#jam
    def jam(self):
        '''این تابع عملیات جمع انجام می دهد'''
        return self.a+self.b
    
    
    def zarb(self):
        return self.a*self.b


t1=Test(19,3)
print(t1.a)
j1=t1.jam()
z1=t1.zarb()
print(f'the result of \'+\' is : {j1}')
print(f"the result of '*' is : {z1}")
t2=Test(15,10)

j2=t2.jam()
z2=t2.zarb()
print(t2.a)
print(t1.b)
print(f'the result of \'+\' is : {j2}')
print(f"the result of '*' is : {z2}")
