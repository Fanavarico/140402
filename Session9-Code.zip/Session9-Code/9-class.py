class Acount:
    def __init__(x,balence, owner):
        x.balence=balence
        x.owner=owner
    
    def deposit(x,amount):
        x.balence=x.balence+amount
        return x.balence
    
    def withdraw(x,amount):
        if x.balence<amount:
            print('Error')
        elif x.balence>=amount:
            x.balence=x.balence-amount
            
        return x.balence
    
a=Acount(1000,'a')
d=a.deposit(400)
print(d)
w=a.withdraw(1000)
print(w)
d1=a.deposit(500)
print(d1)
print(a.balence)
w1=a.withdraw(10)
print(w1)
b=Acount(100,'b')
d2=b.deposit(10)
print(d2)
print(b.balence)
