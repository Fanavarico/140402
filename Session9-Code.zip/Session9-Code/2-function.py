balence=1000
def deposit(amount):
    global balence
    balence=balence+amount
    return balence


def withdraw(amount):
    global balence
    if amount>balence:
        print('error')
        
    elif amount<=balence:
        balence=balence-amount
        
    return balence

d=deposit(10)
print(d)

y=withdraw(2000)
print(y)
print(balence)


    