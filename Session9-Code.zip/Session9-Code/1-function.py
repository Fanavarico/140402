def deposit(amount,balence):
    balence=balence+amount
    return balence


def withdraw(amount,balence):
    if amount>balence:
        print('error')
        
    elif amount<=balence:
        balence=balence-amount
        
    return balence


b=1000
d=deposit(10,b)
print(d)
print(b)
y=withdraw(200,b)
print(y)
print(b)


    