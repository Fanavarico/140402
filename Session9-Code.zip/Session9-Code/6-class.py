class Circle:
    def __init__(self,r):
        self.r=r
        self.p=3.14
        
    def moh(self):
        return f'mohit: {self.r*self.p*2}'
    
    def mas(self):
        return f'masahat: {(self.r**2)*self.p}'
    
s=float(input('enter raduis: '))
i=input('select your opration: mohit or masahat:')
c1=Circle(s)
if i=='mohit':
    print(c1.moh())
elif i=='masahat':
    print(c1.mas())
    