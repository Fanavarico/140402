class Book:
    def __init__(self,a,bn):
        self.author=a
        self.book_name=bn
        
    def __str__(self):
        return f'author of this {self.book_name} \
            is {self.author}'
    
    
b1=Book('a1','bn1')

print(b1)
