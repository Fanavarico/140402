import item


print(r)