class Book:
    def __init__(self,a,bn):
        self.author=a
        self.book_name=bn
        
    def info(self):
        return f'author of this {self.book_name} \
            is {self.author}'
    
    
b1=Book('a1','bn1')
h=b1.info()
print(h)
print(b1)