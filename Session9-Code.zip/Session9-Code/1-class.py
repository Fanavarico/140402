class Test:
    def set_var(self,a,b):
        self.a=a
        self.b=b
    
    def jam(self):
        return self.a+self.b
    
    
    def zarb(self):
        return self.a*self.b


t1=Test()
t1.set_var(19, 3)
j1=t1.jam()
z1=t1.zarb()
print(f'the result of \'+\' is : {j1}')
print(f"the result of '*' is : {z1}")
t2=Test()
t2.set_var(15, 10)
j2=t2.jam()
z2=t2.zarb()
print(t2.a)
print(t1.b)
print(f'the result of \'+\' is : {j2}')
print(f"the result of '*' is : {z2}")