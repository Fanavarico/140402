class Acount:
    def __init__(self,balence, owner):
        self.balence=balence
        self.owner=owner
    
    def deposit(self,amount):
        self.balence=self.balence+amount
        return self.balence
    
    def withdraw(self,amount):
        if self.balence<amount:
            print('Error')
        elif self.balence>=amount:
            self.balence=self.balence-amount
            
        return self.balence
    
a=Acount(1000,'a')
d=a.deposit(400)
print(d)
w=a.withdraw(1000)
print(w)
d1=a.deposit(500)
print(d1)
print(a.balence)
w1=a.withdraw(10)
print(w1)
b=Acount(100,'b')
d2=b.deposit(10)
print(d2)
print(b.balence)
