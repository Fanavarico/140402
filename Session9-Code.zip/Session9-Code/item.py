class Item:
    def __init__(self, id_i, name, number, price):
        self.id_i=id_i
        self.name=name
        self.number=number
        self.price=price
    
    def __str__(self):
        return f'ID:{self.id_i} , Name: {self.name}\
            Number:{self.number}, Price:{self.price}'
            
if '__name__'=='__main__' : 
              
    i=Item(10,'Tshirt',14,10000)
    print(i)